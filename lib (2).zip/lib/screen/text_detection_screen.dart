import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart' show WriteBuffer;
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:google_mlkit_language_id/google_mlkit_language_id.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:animate_do/animate_do.dart';
import 'package:permission_handler/permission_handler.dart';

class TextDetectionScreen extends StatefulWidget {
  final List<CameraDescription> cameras;
  const TextDetectionScreen({super.key, required this.cameras});

  @override
  State<TextDetectionScreen> createState() => _TextDetectionScreenState();
}

class _TextDetectionScreenState extends State<TextDetectionScreen> with WidgetsBindingObserver {
  late CameraController _cameraController;
  bool isCameraReady = false;
  String result = "Initializing...";
  String detectedLanguage = "Unknown";
  final TextRecognizer _textRecognizer = TextRecognizer();
  final LanguageIdentifier _languageIdentifier = LanguageIdentifier(confidenceThreshold: 0.5);
  bool _isDisposed = false;
  bool _useLiveFeed = true;
  bool _isTtsEnabled = false;
  final FlutterTts _tts = FlutterTts();
  final _isProcessing = ValueNotifier<bool>(false);
  DateTime _lastProcessed = DateTime.now();
  final Duration _processingInterval = const Duration(milliseconds: 1000);

  static const Map<String, String> _languageToTtsCode = {
    "en": "en-US",
    "fr": "fr-FR",
    "es": "es-ES",
    "de": "de-DE",
    "it": "it-IT",
    "pt": "pt-PT",
    "ru": "ru-RU",
    "zh": "zh-CN",
    "ja": "ja-JP",
    "ko": "ko-KR",
  };
  static const Map<String, String> _languageToName = {
    "en": "English",
    "fr": "French",
    "es": "Spanish",
    "de": "German",
    "it": "Italian",
    "pt": "Portuguese",
    "ru": "Russian",
    "zh": "Chinese",
    "ja": "Japanese",
    "ko": "Korean",
    "und": "Unknown",
  };
  static const String _defaultTtsLanguage = "en-US";

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
    _initializeTts();
  }

  Future<void> _initializeCamera() async {
    if (_isDisposed) return;
    if (!await _checkPermissions()) {
      setState(() => result = "Camera or storage permission denied");
      return;
    }
    for (int attempt = 1; attempt <= 3; attempt++) {
      try {
        debugPrint("Camera initialization attempt $attempt");
        final camera = widget.cameras.isNotEmpty
            ? widget.cameras.firstWhere(
              (camera) => camera.lensDirection == CameraLensDirection.back,
          orElse: () => widget.cameras.first,
        )
            : throw Exception("No cameras available");
        debugPrint("Selected camera: ${camera.name}, lens: ${camera.lensDirection}");
        _cameraController = CameraController(
          camera,
          ResolutionPreset.medium,
          enableAudio: false,
        );
        debugPrint("Initializing camera...");
        await _cameraController.initialize();
        debugPrint("Camera initialized successfully");
        if (!mounted || _isDisposed) return;
        setState(() {
          isCameraReady = true;
          result = "Detecting...";
        });
        if (_useLiveFeed) {
          debugPrint("Starting image stream");
          _startImageStream();
        }
        return;
      } catch (e) {
        debugPrint("Camera initialization error (attempt $attempt): $e");
        if (attempt == 3) {
          if (!_isDisposed) {
            setState(() => result = "Camera error after $attempt attempts: $e");
          }
          return;
        }
        await Future.delayed(Duration(milliseconds: 500));
      }
    }
  }

  Future<bool> _checkPermissions() async {
    final cameraStatus = await Permission.camera.status;
    final storageStatus = await Permission.storage.status;
    debugPrint("Camera permission: $cameraStatus, Storage permission: $storageStatus");
    if (!cameraStatus.isGranted) {
      final cameraResult = await Permission.camera.request();
      debugPrint("Camera permission request result: $cameraResult");
      if (cameraResult.isPermanentlyDenied && mounted) {
        _showPermissionDialog("Camera");
        return false;
      }
    }
    if (!storageStatus.isGranted && !_useLiveFeed) {
      final storageResult = await Permission.storage.request();
      debugPrint("Storage permission request result: $storageResult");
      if (storageResult.isPermanentlyDenied && mounted) {
        _showPermissionDialog("Storage");
        return false;
      }
    }
    return cameraStatus.isGranted && (_useLiveFeed || storageStatus.isGranted);
  }

  void _showPermissionDialog(String permission) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$permission Permission Required'),
        content: Text('$permission access is required for text detection.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => openAppSettings(),
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  Future<void> _initializeTts() async {
    try {
      await _tts.setLanguage(_defaultTtsLanguage);
      await _tts.setSpeechRate(0.5);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
      debugPrint("TTS initialized successfully with default language: $_defaultTtsLanguage");
      await _tts.speak("TTS initialized");
    } catch (e) {
      debugPrint("TTS initialization error: $e");
      if (mounted && ScaffoldMessenger.of(context).mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("TTS initialization error: $e")),
        );
      }
    }
  }

  Future<String> _detectLanguage(String text) async {
    if (text.isEmpty || text == "No text detected") return _defaultTtsLanguage;
    try {
      final String langCode = await _languageIdentifier.identifyLanguage(text);
      debugPrint("Detected language: $langCode");
      if (langCode == "und") {
        debugPrint("Undetermined language, using default: $_defaultTtsLanguage");
        return _defaultTtsLanguage;
      }
      final ttsCode = _languageToTtsCode[langCode] ?? _defaultTtsLanguage;
      bool isAvailable = await _tts.isLanguageAvailable(ttsCode);
      debugPrint("TTS language $ttsCode available: $isAvailable");
      return isAvailable ? ttsCode : _defaultTtsLanguage;
    } catch (e) {
      debugPrint("Language detection error: $e");
      return _defaultTtsLanguage;
    }
  }

  void _startImageStream() {
    _cameraController.startImageStream((CameraImage image) async {
      debugPrint("Image stream received: ${image.width}x${image.height}");
      if (_isDisposed || _isProcessing.value || !_useLiveFeed) {
        debugPrint("Stream skipped: disposed=$_isDisposed, processing=${_isProcessing.value}, liveFeed=$_useLiveFeed");
        return;
      }
      if (DateTime.now().difference(_lastProcessed) < _processingInterval) {
        debugPrint("Stream skipped: too soon");
        return;
      }
      _isProcessing.value = true;
      _lastProcessed = DateTime.now();
      try {
        await _processLiveImage(image);
      } catch (e) {
        debugPrint("Live text processing error: $e");
        if (mounted && ScaffoldMessenger.of(context).mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Error detecting text: $e")),
          );
        }
      } finally {
        if (!_isDisposed) {
          _isProcessing.value = false;
        }
      }
    });
  }

  Future<void> _processLiveImage(CameraImage cameraImage) async {
    if (_isDisposed) return;
    try {
      final inputImage = await _convertToInputImage(cameraImage);
      final recognizedText = await _textRecognizer.processImage(inputImage);
      debugPrint("Text detected: ${recognizedText.text}");
      if (!mounted || _isDisposed) return;
      final text = recognizedText.text.isNotEmpty ? recognizedText.text : "No text detected";
      final language = await _detectLanguage(text);
      setState(() {
        result = text;
        detectedLanguage = _languageToName[_languageToTtsCode.entries.firstWhere((e) => e.value == language, orElse: () => MapEntry("und", _defaultTtsLanguage)).key] ?? "Unknown";
      });
      if (_isTtsEnabled) {
        debugPrint("Attempting to speak: $text in language: $language");
        await _speakText(text, language);
      }
    } catch (e) {
      debugPrint("Live image processing error: $e");
    }
  }

  Future<void> _capturePhoto() async {
    if (_isDisposed || !isCameraReady || _isProcessing.value) {
      debugPrint("Photo capture skipped: disposed=$_isDisposed, ready=$isCameraReady, processing=${_isProcessing.value}");
      return;
    }
    try {
      _isProcessing.value = true;
      if (_cameraController.value.isStreamingImages) {
        await _cameraController.stopImageStream();
        debugPrint("Image stream paused for photo capture");
      }
      final XFile photo = await _cameraController.takePicture();
      debugPrint("Photo captured: ${photo.path}");
      await _processCapturedPhoto(photo);
      if (_useLiveFeed && isCameraReady) {
        debugPrint("Resuming image stream");
        _startImageStream();
      }
    } catch (e) {
      debugPrint("Photo capture error: $e");
      if (mounted && ScaffoldMessenger.of(context).mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error capturing photo: $e")),
        );
      }
    } finally {
      if (!_isDisposed) {
        _isProcessing.value = false;
      }
    }
  }

  Future<void> _processCapturedPhoto(XFile photo) async {
    if (_isDisposed) return;
    try {
      final inputImage = InputImage.fromFilePath(photo.path);
      final recognizedText = await _textRecognizer.processImage(inputImage);
      debugPrint("Captured photo text detected: ${recognizedText.text}");
      if (!mounted || _isDisposed) return;
      final text = recognizedText.text.isNotEmpty ? recognizedText.text : "No text detected";
      final language = await _detectLanguage(text);
      setState(() {
        result = text;
        detectedLanguage = _languageToName[_languageToTtsCode.entries.firstWhere((e) => e.value == language, orElse: () => MapEntry("und", _defaultTtsLanguage)).key] ?? "Unknown";
      });
      if (_isTtsEnabled) {
        debugPrint("Attempting to speak captured text: $text in language: $language");
        await _speakText(text, language);
      }
    } catch (e) {
      debugPrint("Captured photo processing error: $e");
      if (mounted && ScaffoldMessenger.of(context).mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error detecting text from photo: $e")),
        );
      }
    }
  }

  Future<void> _processGalleryImage() async {
    if (_isDisposed) return;
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile == null) return;
      final inputImage = InputImage.fromFilePath(pickedFile.path);
      final recognizedText = await _textRecognizer.processImage(inputImage);
      debugPrint("Gallery text detected: ${recognizedText.text}");
      if (!mounted || _isDisposed) return;
      final text = recognizedText.text.isNotEmpty ? recognizedText.text : "No text detected";
      final language = await _detectLanguage(text);
      setState(() {
        result = text;
        detectedLanguage = _languageToName[_languageToTtsCode.entries.firstWhere((e) => e.value == language, orElse: () => MapEntry("und", _defaultTtsLanguage)).key] ?? "Unknown";
      });
      if (_isTtsEnabled) {
        debugPrint("Attempting to speak gallery text: $text in language: $language");
        await _speakText(text, language);
      }
    } catch (e) {
      debugPrint("Gallery image processing error: $e");
      if (mounted && ScaffoldMessenger.of(context).mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error detecting text: $e")),
        );
      }
    }
  }

  Future<InputImage> _convertToInputImage(CameraImage image) async {
    try {
      final WriteBuffer allBytes = WriteBuffer();
      for (Plane plane in image.planes) {
        allBytes.putUint8List(plane.bytes);
      }
      final bytes = allBytes.done().buffer.asUint8List();
      const format = InputImageFormat.nv21;
      final expectedSize = image.width * image.height * 1.5;
      debugPrint("Image bytes: ${bytes.length}, expected: $expectedSize, format: $format");
      if (bytes.length < expectedSize) {
        throw Exception("Invalid image data: Byte size (${bytes.length}) does not match expected ($expectedSize)");
      }
      return InputImage.fromBytes(
        bytes: bytes,
        metadata: InputImageMetadata(
          size: Size(image.width.toDouble(), image.height.toDouble()),
          rotation: _getInputImageRotation(),
          format: format,
          bytesPerRow: image.planes[0].bytesPerRow,
        ),
      );
    } catch (e) {
      debugPrint("Convert to InputImage error: $e");
      rethrow;
    }
  }

  InputImageRotation _getInputImageRotation() {
    if (_isDisposed) return InputImageRotation.rotation0deg;
    final sensorOrientation = _cameraController.description.sensorOrientation;
    final deviceOrientation = MediaQuery.of(context).orientation;
    int rotationCompensation = sensorOrientation;
    if (Platform.isAndroid) {
      if (deviceOrientation == Orientation.portrait) {
        rotationCompensation = (sensorOrientation + 90) % 360;
      } else {
        rotationCompensation = sensorOrientation;
      }
    } else if (Platform.isIOS) {
      if (deviceOrientation == Orientation.portrait) {
        rotationCompensation = (sensorOrientation - 90 + 360) % 360;
      }
    }
    debugPrint("Rotation compensation: $rotationCompensation");
    switch (rotationCompensation) {
      case 0:
        return InputImageRotation.rotation0deg;
      case 90:
        return InputImageRotation.rotation90deg;
      case 180:
        return InputImageRotation.rotation180deg;
      case 270:
        return InputImageRotation.rotation270deg;
      default:
        return InputImageRotation.rotation0deg;
    }
  }

  Future<void> _speakText(String text, String language) async {
    if (text == "No text detected" || !_isTtsEnabled) {
      debugPrint("TTS skipped: text='$text', isTtsEnabled=$_isTtsEnabled");
      return;
    }
    try {
      bool isAvailable = await _tts.isLanguageAvailable(language);
      debugPrint("TTS language $language available: $isAvailable");
      if (!isAvailable) {
        debugPrint("Falling back to default language: $_defaultTtsLanguage");
        await _tts.setLanguage(_defaultTtsLanguage);
      } else {
        await _tts.setLanguage(language);
      }
      debugPrint("Speaking text: $text in language: $language");
      await _tts.stop();
      final result = await _tts.speak(text);
      debugPrint("TTS speak result: $result");
    } catch (e) {
      debugPrint("TTS error: $e");
      if (mounted && ScaffoldMessenger.of(context).mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error speaking text: $e")),
        );
      }
    }
  }

  void _toggleInputMode() {
    if (_isDisposed) return;
    setState(() {
      _useLiveFeed = !_useLiveFeed;
      result = _useLiveFeed ? "Detecting..." : "Select an image";
      detectedLanguage = "Unknown";
      debugPrint("Toggled input mode: useLiveFeed=$_useLiveFeed");
    });
    if (_useLiveFeed && isCameraReady) {
      debugPrint("Starting image stream");
      _startImageStream();
    } else {
      _cameraController.stopImageStream().catchError((e) => debugPrint("Error stopping stream: $e"));
    }
  }

  void _toggleTts() {
    if (_isDisposed) return;
    setState(() {
      _isTtsEnabled = !_isTtsEnabled;
      debugPrint("TTS toggled: isTtsEnabled=$_isTtsEnabled");
    });
    if (!_isTtsEnabled) {
      _tts.stop();
      debugPrint("TTS stopped");
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_isDisposed || !isCameraReady || !_cameraController.value.isInitialized) return;
    debugPrint("App lifecycle state: $state");
    if (state == AppLifecycleState.paused) {
      debugPrint("Pausing camera stream due to app lifecycle");
      _cameraController.stopImageStream().catchError((e) => debugPrint("Error stopping stream: $e"));
    } else if (state == AppLifecycleState.resumed && _useLiveFeed && !_cameraController.value.isStreamingImages) {
      debugPrint("Resuming camera stream");
      _startImageStream();
    }
  }

  Future<void> _cleanupResources() async {
    debugPrint("Cleaning up TextDetectionScreen resources");
    try {
      if (_cameraController.value.isStreamingImages) {
        await _cameraController.stopImageStream();
        debugPrint("Camera stream stopped");
      }
      await _cameraController.dispose();
      debugPrint("Camera controller disposed");
      await _textRecognizer.close();
      debugPrint("Text recognizer closed");
      await _languageIdentifier.close();
      debugPrint("Language identifier closed");
      await _tts.stop();
      debugPrint("TTS stopped");
      _isProcessing.dispose();
      debugPrint("Processing notifier disposed");
    } catch (e) {
      debugPrint("Error during cleanup: $e");
    }
  }

  @override
  void dispose() {
    debugPrint("Disposing TextDetectionScreen");
    _isDisposed = true;
    _cleanupResources();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mqData = MediaQuery.of(context);
    if (_isDisposed) return const SizedBox.shrink();
    return WillPopScope(
      onWillPop: () async {
        debugPrint("WillPopScope triggered, cleaning up before pop");
        await _cleanupResources();
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.blue.shade900, Colors.blue.shade700],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          title: FadeInDown(
            child: const Text(
              "Text Detection",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          centerTitle: true,
        ),
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.grey.shade900,
        body: Stack(
          children: [
            // Camera preview or gallery placeholder
            SizedBox(
              width: mqData.size.width,
              height: mqData.size.height,
              child: _useLiveFeed && isCameraReady
                  ? CameraPreview(_cameraController)
                  : const Center(child: Text("Select an image from gallery", style: TextStyle(color: Colors.white))),
            ),
            // Gradient overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.3),
                    Colors.black.withValues(alpha: 0.6),
                  ],
                ),
              ),
            ),
            // Processing indicator (top-right)
            Positioned(
              top: 20,
              right: 20,
              child: ValueListenableBuilder<bool>(
                valueListenable: _isProcessing,
                builder: (context, isProcessing, _) {
                  return isProcessing
                      ? const CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(Colors.blue),
                  )
                      : const SizedBox.shrink();
                },
              ),
            ),
            // TTS toggle (top-right, below processing indicator)
            Positioned(
              top: 60,
              right: 20,
              child: ZoomIn(
                child: FloatingActionButton(
                  heroTag: "tts",
                  backgroundColor: Colors.blue.shade800.withValues(alpha: 0.9),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(
                    _isTtsEnabled ? Icons.volume_up : Icons.volume_off,
                    color: Colors.white,
                    size: 28,
                  ),
                  onPressed: _toggleTts,
                ),
              ),
            ),
            // Switch gallery/live feed (top-left)
            Positioned(
              top: 20,
              left: 20,
              child: FadeInDown(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade700,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _toggleInputMode,
                  child: Text(
                    _useLiveFeed ? "Switch to Gallery" : "Switch to Live Feed",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
            // Detected text and language (bottom container)
            Positioned(
              bottom: 0,
              child: SafeArea(
                top: false,
                child: FadeInUp(
                  duration: const Duration(milliseconds: 600),
                  child: Container(
                    width: mqData.size.width,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.2),
                          blurRadius: 10,
                          offset: const Offset(0, -2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Detected Text",
                          style: TextStyle(
                            color: Colors.blue.shade300,
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: Colors.blue.shade200.withValues(alpha: 0.3),
                            ),
                          ),
                          child: Text(
                            result,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          "Detected Language: $detectedLanguage",
                          style: TextStyle(
                            color: Colors.blue.shade300,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (!_useLiveFeed) ...[
                          const SizedBox(height: 16),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue.shade700,
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            ),
                            onPressed: _processGalleryImage,
                            child: const Text(
                              "Pick Image",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Photo capture (bottom-center, only in live feed)
            if (_useLiveFeed && isCameraReady)
              Positioned(
                bottom: mqData.size.height * 0.15,
                left: mqData.size.width * 0.5 - 28, // Center horizontally
                child: ZoomIn(
                  child: FloatingActionButton(
                    heroTag: "shutter",
                    backgroundColor: Colors.blue.shade800.withValues(alpha: 0.9),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(
                      Icons.camera_alt,
                      color: Colors.white,
                      size: 28,
                    ),
                    onPressed: _capturePhoto,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
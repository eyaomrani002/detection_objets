import 'package:camera/camera.dart';
import 'package:detection_objects/screen/text_detection_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:detection_objects/utils/my_Text_stylr.dart';
import 'dart:io';
import 'dart:async';
import 'package:path_provider/path_provider.dart';
import 'package:vibration/vibration.dart'; // Replace flutter_vibrate with vibration
import 'package:animate_do/animate_do.dart'; // For animations

class ObjectDetectionScreen extends StatefulWidget {
  final List<CameraDescription> cameras;

  const ObjectDetectionScreen({super.key, required this.cameras});

  @override
  State<ObjectDetectionScreen> createState() => _ObjectDetectionScreenState();
}

class _ObjectDetectionScreenState extends State<ObjectDetectionScreen> {
  late CameraController _cameraController;
  bool isCameraReady = false;
  String result = "Detecting...";
  late ImageLabeler _imageLabeler;
  bool isDetecting = false;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _initializeMLKit();
  }

  /// Initialize Camera
  Future<void> _initializeCamera() async {
    _cameraController = CameraController(
      widget.cameras[0],
      ResolutionPreset.ultraHigh,
      enableAudio: false,
    );

    await _cameraController.initialize();
    if (!mounted) return;

    setState(() {
      isCameraReady = true;
    });

    _startImageStream();
  }

  /// Initialize ML Kit
  void _initializeMLKit() {
    _imageLabeler = ImageLabeler(
      options: ImageLabelerOptions(confidenceThreshold: 0.5),
    );
  }

  /// Start Image Stream for Real-time Detection
  void _startImageStream() {
    _cameraController.startImageStream((CameraImage image) async {
      if (isDetecting) return;
      isDetecting = true;
      await _processImage(image);
      isDetecting = false;
    });
  }

  /// Process Camera Frame
  Future<void> _processImage(CameraImage cameraImage) async {
    try {
      final Directory tempDir = await getTemporaryDirectory();
      final String filePath =
          '${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg';
      final File imageFile = File(filePath);

      final XFile picture = await _cameraController.takePicture();
      await picture.saveTo(imageFile.path);

      final inputImage = InputImage.fromFile(imageFile);
      final List<ImageLabel> labels = await _imageLabeler.processImage(inputImage);

      String detectedObjects = labels.isNotEmpty
          ? labels
          .map((label) =>
      "${label.label} - ${(label.confidence * 100).toStringAsFixed(2)}%")
          .join("\n")
          : "No object detected";

      setState(() {
        result = detectedObjects;
      });
    } catch (e) {
      print("Error processing image: $e");
    }
  }

  /// Toggle Flashlight (Torch)
  Future<void> _toggleTorch() async {
    try {
      await _cameraController.setFlashMode(
        _cameraController.value.flashMode == FlashMode.torch
            ? FlashMode.off
            : FlashMode.torch,
      );
      Vibration.vibrate(duration: 50); // Haptic feedback with vibration package
      setState(() {});
    } catch (e) {
      print("Torch error: $e");
    }
  }

  @override
  void dispose() {
    _cameraController.dispose();
    _imageLabeler.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mqData = MediaQuery.of(context);
    final isTorchOn = isCameraReady && _cameraController.value.flashMode == FlashMode.torch;

    return Scaffold(
      /// -------------- Appbar --------------------- ///
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue.shade900, Colors.blue.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        title: FadeInDown(
          child: Text(
            "Object Detection",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        centerTitle: true,
        leading: Padding(
          padding: EdgeInsets.all(12.0),
          child: Image.asset(
            "assets/icons/object.png",
            color: Colors.white.withOpacity(0.9),
          ),
        ),
        // Ajout du bouton de navigation vers l'écran de détection de texte
        actions: [
          IconButton(
            icon: Icon(Icons.text_fields, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TextDetectionScreen(cameras: widget.cameras),
                ),
              );
            },
          ),
          SizedBox(width: 8),
        ],
      ),
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.grey.shade900,

      ///----------------- BODY --------------------///
      body: Stack(
        children: [
          /// Camera Preview
          SizedBox(
            width: mqData.size.width,
            height: mqData.size.height,
            child: isCameraReady
                ? ClipRRect(
              child: CameraPreview(_cameraController),
            )
                : Center(
              child: CircularProgressIndicator(
                color: Colors.blue.shade400,
              ),
            ),
          ),

          /// Overlay Gradient for better text readability
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.3),
                  Colors.black.withOpacity(0.6),
                ],
              ),
            ),
          ),

          /// Detection Result
          Positioned(
            bottom: 0,
            child: FadeInUp(
              duration: Duration(milliseconds: 600),
              child: Container(
                width: mqData.size.width,
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      offset: Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Detected Objects",
                      style: myTextStyle18(
                        fontWeight: FontWeight.w700,
                        fontColors: Colors.blue.shade300,
                      ),
                    ),
                    SizedBox(height: 12),
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.blue.shade200.withOpacity(0.3),
                        ),
                      ),
                      child: Text(
                        result,
                        style: myTextStyle18(
                          fontColors: Colors.white,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          /// Flash Toggle Button
          Positioned(
            bottom: 100,
            right: 20,
            child: ZoomIn(
              child: FloatingActionButton(
                backgroundColor: Colors.blue.shade800.withOpacity(0.9),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  isTorchOn ? Icons.flash_off : Icons.flash_on,
                  color: Colors.white,
                  size: 28,
                ),
                onPressed: _toggleTorch,
              ),
            ),
          ),
        ],
      ),
    );
  }
}